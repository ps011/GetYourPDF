<?php
if(!mysql_connect("localhost","u307431508_pm","HUAIKPk6zO"))
{
     die('oops connection problem ! --> '.mysql_error());
}
if(!mysql_select_db("db"))
{
     die('oops database selection problem ! --> '.mysql_error());
}
?>