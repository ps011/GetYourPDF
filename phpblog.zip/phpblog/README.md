# blog
Simple blog implemented using html,css,bootstrap,php and mysql
