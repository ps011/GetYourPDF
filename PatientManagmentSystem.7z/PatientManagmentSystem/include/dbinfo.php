<?php
$server='localhost';
$user='root';
$pass='';
$db='HMS';
$admin='ITS6801';
?>
