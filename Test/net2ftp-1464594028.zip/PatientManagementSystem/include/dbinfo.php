<?php
$server='localhost';
$user='u307431508_pm';
$pass='HUAIKPk6zO';
$db='u307431508_db';
$admin='ITS6801';
?>
