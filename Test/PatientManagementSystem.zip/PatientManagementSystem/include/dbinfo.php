<?php
$server='localhost';
$user='root';
$pass='';
$db='hms';
$admin='ITS6801';
?>
