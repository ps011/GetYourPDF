Note
====
Car Zone Automobile Bootstrap Responsive Web Template
 
Author URI: http://webthemez.com/
Description: 
Car Zone is a AutoMobile responsive web template can be used as a website for Car Wash, Car Service, Car care, Car Showrooms, Car Spare and Accessories showrooms. This template is developed on bootstrap framework and supports all browsers and devices like Mobile phones and Tabs.


Credits
=======
Framework  http://getbootstrap.com
Images	(http://unsplash.com - CC0 licensed)
Icons	Font Awesome (http://fortawesome.github.com/Font-Awesome/)
Other	html5shiv.js (@afarkas @jdalton @jon_neal @rem)

Note: All the images used in this template is for demo use only, we are not responsible for any copyrights issue.	